﻿using System.Collections.Generic;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGridCellInfo
    {
        public MyGridCellInfo(int x, int y)
        {
            X = x;
            Y = y;
        }

        public int X { get; }
        public int Y { get; }

        public List<long> EnemyTanks { get; } = new List<long>();
        public List<long> EnemySamolets { get;  } = new List<long>();
        public List<long> EnemyCopters { get;  } = new List<long>();
        public List<long> EnemyZeneitkas { get;  } = new List<long>();
        public List<long> EnemyRemonts { get;  } = new List<long>();

        public Facility Facility { get; set; }
        public int TagetSquad { get; set; }
        public MySquad Squad { get; set; }

        public int EnemyCount
        {
            get { return EnemyCopters.Count + EnemySamolets.Count + EnemyTanks.Count; }
        }


        public bool IsEnemyCell { get; set; }

        public bool IsFight{ get; set; }

        public void Clear()
        {
            EnemyTanks.Clear();
            EnemySamolets.Clear();
            EnemyCopters.Clear();
            EnemyZeneitkas.Clear();
            EnemyRemonts.Clear();

            Facility = null;
            Squad = null;
            TagetSquad = 0;

            IsEnemyCell = false;
            IsFight = false;

        }
    }
}
