﻿using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyEnemyStrategyRecognizer
    {
        private MyStrategy _strategy;

        public MyEnemyStrategyRecognizer(MyStrategy strategy)
        {
            _strategy = strategy;
        }

        public EnemyStrategyType Recognize()
        {
            var randomTank = _strategy.EnemyVehicles.FirstOrDefault(v => v.Type == VehicleType.Tank);
            if (randomTank == null)
            {
                return EnemyStrategyType.Solo;
            }

            var groupSize = _strategy.EnemyVehicles.Count(v => v.GetDistanceTo(randomTank.X, randomTank.Y) < 150);

            if (groupSize >= 160)
            {
                return EnemyStrategyType.Solo;
            }
            else
            {
                return EnemyStrategyType.Spread;
            }

        }
    }
}
