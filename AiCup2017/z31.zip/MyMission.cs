﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum MissionType
    {
        GetEmptyFacility,
        GetEnemyFacilityWithFight,
        Move,
        Defend,
        Remont,
        ForTank,
        ForZenitka,
        ForRemont,
        ForSamolet,
        ForCopter,
    }

    public class MyMission
    {
        public MissionType Type { get; set; }

        public Queue<Task<bool>> Mission { get; set; }
    }
}
