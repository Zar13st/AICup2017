﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum Group
    {
        Remont = 1,
        Fighter,
        Helicopter,
        Zenitka,
        Tank,
        All,
        Air,
        Land,
        Army1,
        Army2,
        Army3,
        Army4,
        Air1,
        Air2,
        Air3,
        Air4,
        LandGroup1,
        LandGroup2,
        LandGroup3,
        LandGroup4,
        Temp1,
        Temp2,
        Temp3,
    }
}
