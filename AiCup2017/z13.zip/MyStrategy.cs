using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk {
    public sealed class MyStrategy : IStrategy {

        public Queue<Task<bool>> MainGameTasks { get; set; } = new Queue<Task<bool>>();
        public Queue<Task<bool>> NuclearGameTasks { get; set; } = new Queue<Task<bool>>();

        public List<MyUnitWithDelayedTask> Units { get; set; } = new List<MyUnitWithDelayedTask>();
        public List<MyUnitWithDelayedTask> UnitsForRemove { get; set; } = new List<MyUnitWithDelayedTask>();
        public List<MyUnitWithDelayedTask> UnitsForAdd { get; set; } = new List<MyUnitWithDelayedTask>();

        public Player Me { get; set; }
        public World World { get; set; }
        public Game Game { get; set; }
        public Move Action { get; set; }

        public Dictionary<long, Vehicle> VehicleById { get; set; } = new Dictionary<long, Vehicle>();
        public Dictionary<long, int> UpdateTickByVehicleId { get; set; } = new Dictionary<long, int>();

        public IEnumerable<Vehicle> MyVehicles{get { return VehicleById.Values.Where(v => v.PlayerId == Me.Id); }}

        public IEnumerable<Vehicle> EnemyVehicles { get { return VehicleById.Values.Where(v => v.PlayerId != Me.Id); }}

        public MyDelayTaksBuilder DelayTaksBuilder { get; set; }
        public MyEnemyStrategyRecognizer EnemyStrategyRecognizer { get; set; }

        public Group CurrentGroup { get; set; }
        public EnemyStrategyType EnemyType { get; set; } = EnemyStrategyType.Unknown;

        private bool _nuclearAlarm;
        private bool _scaleAfterNuclearAlarm = true;
        private bool GroupingEnded { get; set; }
        private MyGroupAtStartMaker _groupMaker;       
        private Random _random;
        private Action DoAfterNuclear;

        private TerrainType[][] _terrainTypeByCellXY;
        private WeatherType[][] _weatherTypeByCellXY;

        public void Move(Player me, World world, Game game, Move move)
        {
            InitializeStrategy(world, game);
            InitializeTick(me, world, game, move);

            if (me.RemainingActionCooldownTicks != 0){return;}

            CheckNuclearAlarm();


            if (MainGameTasks.Any() && _scaleAfterNuclearAlarm)
            {
                MainGameTasks.Dequeue().RunSynchronously();
                return;
            }
        }

        private MyPoint _nuclearPoint = new MyPoint();
        private int _nuclearAlarmTick = 20001;
        private void CheckNuclearAlarm()
        {
            if (EnemyType != EnemyStrategyType.Unknown)
            {

                if (World.GetOpponentPlayer().RemainingNuclearStrikeCooldownTicks > 900 && !_nuclearAlarm)
                {
                    var x = World.GetOpponentPlayer().NextNuclearStrikeX;
                    var y = World.GetOpponentPlayer().NextNuclearStrikeY;
                    if (x <= 0 && y <= 0)
                    {
                        return;
                    }
                    _nuclearAlarm = true;
                    _scaleAfterNuclearAlarm = false;
                    _nuclearAlarmTick = World.TickIndex;
  
                    _nuclearPoint = new MyPoint(x, y);
                    NuclearGameTasks.Enqueue(SelectByGroup(Group.All));
                    NuclearGameTasks.Enqueue(Scale(10, _nuclearPoint));
                }

                if (World.GetOpponentPlayer().RemainingNuclearStrikeCooldownTicks <= 800 && _nuclearAlarm)
                {
                    _nuclearAlarm = false;
                }

                if (World.TickIndex >= _nuclearAlarmTick + 31)
                {
                    _nuclearAlarmTick = 20001;
                    NuclearGameTasks.Enqueue(SelectByGroup(Group.All));
                    NuclearGameTasks.Enqueue(Scale(0.1, _nuclearPoint));

                    DelayTaksBuilder.Create(Group.All, () => { _scaleAfterNuclearAlarm = true; });
                }
            }

            if (NuclearGameTasks.Any())
            {
                NuclearGameTasks.Dequeue().RunSynchronously();
                return;
            }
        }

        private void InitializeStrategy(World world, Game game)
        {
            if (_random == null)
            {
                DelayTaksBuilder = new MyDelayTaksBuilder(this);
                EnemyStrategyRecognizer = new MyEnemyStrategyRecognizer(this);
                _random = new Random();

                _terrainTypeByCellXY = world.TerrainByCellXY;
                _weatherTypeByCellXY = world.WeatherByCellXY;             
            }
        }

        private void InitializeTick(Player me, World world, Game game, Move move)
        {
            Me = me;
            World = world;
            Game = game;
            Action = move;

            foreach ( Vehicle vehicle in World.NewVehicles)
            {
                VehicleById[vehicle.Id] = vehicle;
                UpdateTickByVehicleId[vehicle.Id] = world.TickIndex;
            }

            foreach (VehicleUpdate vehicleUpdate in world.VehicleUpdates)
            {
                long vehicleId = vehicleUpdate.Id;

                if (vehicleUpdate.Durability == 0)
                {
                    VehicleById.Remove(vehicleId);
                    UpdateTickByVehicleId.Remove(vehicleId);
                }
                else
                {
                    VehicleById[vehicleId] =  new Vehicle(VehicleById[vehicleId], vehicleUpdate);
                    UpdateTickByVehicleId[vehicleId] = world.TickIndex;
                }
            }

            foreach (var unit in UnitsForRemove)
            {
                Units.Remove(unit);
            }
            UnitsForRemove.Clear();

            foreach (var unit in UnitsForAdd)
            {
                Units.Add(unit);
            }
            UnitsForAdd.Clear();

            foreach (var unit in Units)
            {
                unit.CheckDelayedTask();
            }

            if (World.TickIndex == 0)
            {
                _groupMaker = new MyGroupAtStartMaker(this);
                _groupMaker.Make();

            }

            if (GroupingEnded && Me.RemainingNuclearStrikeCooldownTicks <= 0)
            {
                if (World.TickIndex % 10 == 0)
                {
                    var myCenter = MyVehicles.CenterXY();
                    var enemyCenter = EnemyVehicles.CenterXY();
                    if (myCenter.GetSqrDistance(enemyCenter) < 10000)
                    {
                        var samoletId = MyVehicles
                            .Where(v => v.Durability == 100 &&
                                        (v.Type == VehicleType.Fighter || v.Type == VehicleType.Helicopter)).Select(v => v.Id).FirstOrDefault();
                        MainGameTasks.Enqueue(Nuclear(new MyPoint(VehicleById[samoletId].X + 60, VehicleById[samoletId].Y + 60), samoletId));
                        MainGameTasks.Enqueue(Scale(0.1));
                    }
                }
            }
        }

        public void StartMarch()
        {
            EnemyType = EnemyStrategyRecognizer.Recognize();

            switch (EnemyType)
            {
                case EnemyStrategyType.Solo:
                {
                    GroupingEnded = true;

                    DoAfterNuclear = SoloFoght;
                    SoloFoght();

                    break;
                }
                case EnemyStrategyType.Spread:
                {
                    DoAfterNuclear = FindSingleEnemy;

                    FindSingleEnemy();
                    break;
                }
                default:
                break;
            }


        }

        private void SoloFoght()
        {
            var enemyCenter = EnemyVehicles.CenterXY();

            MainGameTasks.Enqueue(SelectByGroup(Group.All));
            MainGameTasks.Enqueue(MoveSlowToPoint(new MyPoint(enemyCenter.X, enemyCenter.Y)));

            //var tasksAtPoint = new Queue<Task<bool>>();
            //tasksAtPoint.Enqueue(SelectByGroup(Group.All));
            //tasksAtPoint.Enqueue(Scale(0.1, MyVehicles.CenterXY()));

            DelayTaksBuilder.Create(Group.All, StartMarch);
        }



        private void FindSingleEnemy()
        {
            var myRandomUnit = MyVehicles.First();

            double distance = 10000;
            foreach (var vehicle in EnemyVehicles)
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }
            KillSingleEnemy();

        }

        private MyPoint nearestEnemyPoint = new MyPoint();
        private void KillSingleEnemy()
        {
            MainGameTasks.Enqueue(SelectByGroup(Group.All));
            MainGameTasks.Enqueue(MoveSlowToPoint(nearestEnemyPoint, 0.3d));

            DelayTaksBuilder.Create(Group.All, FindSingleEnemy);
        }

        public Task<bool> Nuclear(MyPoint p, long vId)
        {
            var task = new Task<bool>(() =>
            {
                Action.Action = ActionType.TacticalNuclearStrike;
                Action.X = p.X;
                Action.Y = p.Y;
                Action.VehicleId = vId;

                return true;
            });

            return task;
        }

        public Task<bool> MoveByVector(MyPoint vector)
        {
            var task = new Task<bool>(() =>
            {
                Action.Action = ActionType.Move;
                Action.X = vector.X;
                Action.Y = vector.Y;

                return true;
            });

            return task;
        }

        public Task<bool> MoveToPoint(MyPoint point)
        {
            var task = new Task<bool>(() =>
            {
                var centerGroup = MyVehicles.Where(v => v.IsSelected).CenterXY();

                var targetX = point.X - centerGroup.X;
                var targetY = point.Y - centerGroup.Y;

                Action.Action = ActionType.Move;
                Action.X = targetX;
                Action.Y = targetY;

                return true;
            });

            return task;
        }

        public Task<bool> Scale(double factor)
        {
            var task = new Task<bool>(() =>
            {
                var centerGroup = MyVehicles.Where(v => v.IsSelected).CenterXY();

                Action.Action = ActionType.Scale;
                Action.Factor = factor;
                Action.X = centerGroup.X;
                Action.Y = centerGroup.Y;

                return true;
            });

            return task;
        }

        public Task<bool> Scale(double factor, MyPoint point)
        {
            var task = new Task<bool>(() =>
            {

                Action.Action = ActionType.Scale;
                Action.Factor = factor;
                Action.X = point.X;
                Action.Y = point.Y;

                return true;
            });

            return task;
        }

        public Task<bool> SelectByGroup(Group group)
        {
            var task = new Task<bool>(() =>
            {
                Action.Action = ActionType.ClearAndSelect;
                Action.Group = (int) group;
                CurrentGroup = group;
                return true;
            });
            return task;
        }

        public Task<bool> FastCenterRotate(double angel)
        {
            var task = new Task<bool>(() =>
            {
                var center = MyVehicles.Where(v => v.IsSelected).CenterXY();
                angel = angel * Math.PI / 180d;
                Action.Action = ActionType.Rotate;
                Action.X = center.X;
                Action.Y = center.Y;
                Action.Angle = angel;

                return true;
            });
            return task;
        }

        public Task<bool> CenterRotate(double angel)
        {
            var task = new Task<bool>(() =>
            {
                var center = MyVehicles.Where(v => v.IsSelected).CenterXY();
                angel = angel * Math.PI / 180d;
                Action.Action = ActionType.Rotate;
                Action.X = center.X;
                Action.Y = center.Y;
                Action.Angle = angel;
                Action.MaxSpeed = Game.TankSpeed;

                return true;
            });
            return task;
        }

        public Task<bool> MoveSlowToPoint(MyPoint point, double speed = 0.18)
        {
            var task = new Task<bool>(() =>
            {
                var centerGroup = MyVehicles.Where(v => v.IsSelected).CenterXY();

                var targetX = point.X - centerGroup.X;
                var targetY = point.Y - centerGroup.Y;

                Action.Action = ActionType.Move;
                Action.X = targetX;
                Action.Y = targetY;
                Action.MaxSpeed = speed;

                return true;
            });

            return task;
        }

    }
}