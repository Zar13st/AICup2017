﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGroupAtStartMaker
    {
        private int _dl = 80;

        private readonly MyStrategy _strategy;

        private Dictionary<Group, MyPoint> _positions = new Dictionary<Group, MyPoint>();

        public MyGroupAtStartMaker(MyStrategy strategy)
        {
            _strategy = strategy;
        }

        public void Make()
        {
            foreach (var typeInt in Enum.GetValues(typeof(VehicleType)))
            {
                var center = _strategy.MyVehicles.Where(v => (int)v.Type == (int)typeInt).CenterXY();

                int x = Convert.ToInt32(center.X);
                int y = Convert.ToInt32(center.Y);

                _positions[((VehicleType)typeInt).ToGroup()] = new MyPoint(x/ _dl, y / _dl );
            }
            _strategy.MainGameTasks.Enqueue(SelectByFrameTask(new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.All));

            MoveTopAndDownLandGroup();

            GroupAir();
        }

        private void GroupAir()
        {
            VehicleType fistGroup = VehicleType.Helicopter;
            VehicleType secondGroup = VehicleType.Fighter;
            if (_positions[Group.Fighter].X + _positions[Group.Fighter].Y >=
                _positions[Group.Helicopter].X + _positions[Group.Helicopter].Y)
            {
                fistGroup = VehicleType.Fighter;
                secondGroup = VehicleType.Helicopter;
            }
         
            _strategy.MainGameTasks.Enqueue(SelectByTypeAndFrameTask(fistGroup, new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(fistGroup.ToGroup()));

            _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(193, 193)));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Air));

            var delayedTask1 = new Queue<Task<bool>>();
            delayedTask1.Enqueue(_strategy.SelectByGroup(fistGroup.ToGroup()));
            delayedTask1.Enqueue(_strategy.MoveToPoint(new MyPoint(179, 119)));

            _strategy.DelayTaksBuilder.Create(fistGroup.ToGroup(), delayedTask1);


            _strategy.MainGameTasks.Enqueue(SelectByTypeAndFrameTask(secondGroup, new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(secondGroup.ToGroup()));

            _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(45, 45)));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Air));

            var delayedTask2 = new Queue<Task<bool>>();
            delayedTask2.Enqueue(_strategy.SelectByGroup(secondGroup.ToGroup()));
            delayedTask2.Enqueue(_strategy.MoveToPoint(new MyPoint(59, 119)));
            _strategy.DelayTaksBuilder.Create(secondGroup.ToGroup(), delayedTask2);

      
        }

        private Group[] _landGroups;
        private void MoveTopAndDownLandGroup()
        {
            _landGroups =_positions.Where(v=>v.Key != Group.Fighter && v.Key != Group.Helicopter).OrderBy(v => v.Value.X + v.Value.Y).Select(v=> v.Key).ToArray();

            if (_positions[_landGroups[0]].Ravno(new MyPoint(1, 0)) &&_positions[_landGroups[1]].Ravno(new MyPoint(0, 1)))
            {
                _landGroups.Swap(0,1);
            }
            if (_positions[_landGroups[1]].Ravno(new MyPoint(2, 1)) &&_positions[_landGroups[2]].Ravno(new MyPoint(1, 2)))
            {
                _landGroups.Swap(1,2);
            }
            if (_positions[_landGroups[1]].Ravno(new MyPoint(0, 2)) && _positions[_landGroups[0]].Ravno(new MyPoint(1, 1)))
            {
                _landGroups.Swap(1, 0);
            }
            if (_positions[_landGroups[1]].Ravno(new MyPoint(2, 0)) && _positions[_landGroups[2]].Ravno(new MyPoint(1, 1)))
            {
                _landGroups.Swap(1, 2);
            }


            _strategy.MainGameTasks.Enqueue(SelectByTypeAndFrameTask(_landGroups[2].ToVehicleType(), new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(_landGroups[2]));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Land));

            if (_positions[_landGroups[2]].Ravno(new MyPoint(2, 2)) ||
                _positions[_landGroups[2]].Ravno(new MyPoint(2, 0)) ||
                (_positions[_landGroups[2]].Ravno(new MyPoint(2, 1))&& !_positions[_landGroups[1]].Ravno(new MyPoint(2, 0))))
            {
                MoveMidLandGroup();
            }
            else
            {
                _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(193, 193)));

                _strategy.DelayTaksBuilder.Create(_landGroups[2], MoveMidLandGroup);
            }
 
            _strategy.MainGameTasks.Enqueue(SelectByTypeAndFrameTask(_landGroups[0].ToVehicleType(), new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(_landGroups[0]));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Land));

            if (_positions[_landGroups[0]].Ravno(new MyPoint(0, 0)) ||
                _positions[_landGroups[0]].Ravno(new MyPoint(0, 2)) ||
                (_positions[_landGroups[0]].Ravno(new MyPoint(0, 1)) && !_positions[_landGroups[1]].Ravno(new MyPoint(0, 2))))
            {
                MoveMidLandGroup();
            }
            else
            {
                _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(45, 45)));

                _strategy.DelayTaksBuilder.Create(_landGroups[0], MoveMidLandGroup);
            }

        }

        private int landTopAndDownGroupFinished = 0;
        private void MoveMidLandGroup()
        {
            landTopAndDownGroupFinished++;
            if (landTopAndDownGroupFinished == 2)
            {
                _strategy.MainGameTasks.Enqueue(SelectByTypeAndFrameTask(_landGroups[1].ToVehicleType(), new MyPoint(0, 0), new MyPoint(_strategy.World.Width, _strategy.World.Height)));

                _strategy.MainGameTasks.Enqueue(AssignToGroupTask(_landGroups[1]));
                _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Land));

                if (!_positions[_landGroups[1]].Ravno(new MyPoint(1, 1)))
                {
                    _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(119, 119)));
                }


                if (_positions[_landGroups[1]].X == 1)
                {
                    LastMoveToGroup();
                }
                else
                {
                    _strategy.DelayTaksBuilder.Create(_landGroups[1], LastMoveToGroup);
                }
            }
        }

        private void LastMoveToGroup()
        {
            _strategy.MainGameTasks.Enqueue(_strategy.SelectByGroup(_landGroups[0]));
            _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(59, 119)));

            _strategy.MainGameTasks.Enqueue(_strategy.SelectByGroup(_landGroups[2]));
            _strategy.MainGameTasks.Enqueue(_strategy.MoveToPoint(new MyPoint(179, 119)));

            _strategy.DelayTaksBuilder.Create(Group.All, VehicleToRows);
        }


        private void VehicleToRows()
        {
            for (int i = 0; i < 9; i++)
            {
                _strategy.MainGameTasks.Enqueue(SelectByFrameTask(new MyPoint(0, 143 - i * 6),new MyPoint(_strategy.World.Width, 149 - i * 6)));
                _strategy.MainGameTasks.Enqueue(_strategy.MoveByVector(new MyPoint(0, (9 - i) * 12)));
            }

            _strategy.DelayTaksBuilder.Create(Group.All, MergeUnits);
        }

        private void MergeUnits()
        {
            _strategy.MainGameTasks.Enqueue(SelectByFrameTask(new MyPoint(0, 0), new MyPoint(89, _strategy.World.Width)));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Temp1));
            _strategy.MainGameTasks.Enqueue(_strategy.MoveByVector(new MyPoint(0, -6)));

            _strategy.DelayTaksBuilder.Create(Group.Temp1, EndMergeUnits);


            _strategy.MainGameTasks.Enqueue(SelectByFrameTask(new MyPoint(149, 0),new MyPoint(_strategy.World.Height, _strategy.World.Width)));
            _strategy.MainGameTasks.Enqueue(AssignToGroupTask(Group.Temp2));
            _strategy.MainGameTasks.Enqueue(_strategy.MoveByVector(new MyPoint(0, 6)));

            _strategy.DelayTaksBuilder.Create(Group.Temp2, EndMergeUnits);
        }

        private int mergeUnitsCount = 0;
        private void EndMergeUnits()
        {
            mergeUnitsCount++;
            if (mergeUnitsCount == 2)
            {
                _strategy.MainGameTasks.Enqueue(_strategy.SelectByGroup(Group.Temp1));
                _strategy.MainGameTasks.Enqueue(_strategy.MoveByVector(new MyPoint(60, 0)));

                _strategy.MainGameTasks.Enqueue(_strategy.SelectByGroup(Group.Temp2));
                _strategy.MainGameTasks.Enqueue(_strategy.MoveByVector(new MyPoint(-60, 0)));

                _strategy.DelayTaksBuilder.Create(Group.All, RotateGroup);
            }
        }

        private void RotateGroup()
        {
            _strategy.MainGameTasks.Enqueue(_strategy.SelectByGroup(Group.All));
            _strategy.MainGameTasks.Enqueue(_strategy.FastCenterRotate(45));

            _strategy.DelayTaksBuilder.Create(Group.All, StayAtOne);
        }

        private void StayAtOne()
        {
            _strategy.MainGameTasks.Enqueue(_strategy.Scale(0.1));

            _strategy.DelayTaksBuilder.Create(Group.All, _strategy.StartMarch);
        }

        public Task<bool> SelectByTypeAndFrameTask(VehicleType type, MyPoint leftTop, MyPoint rigthBot)
        {
            var task = new Task<bool>(() =>
            {
                _strategy.Action.Action = ActionType.ClearAndSelect;
                _strategy.Action.VehicleType = type;
                _strategy.Action.Left = leftTop.X;
                _strategy.Action.Top = leftTop.Y;
                _strategy.Action.Right = rigthBot.X;
                _strategy.Action.Bottom = rigthBot.Y;

                return true;
            });

            return task;
        }

        public Task<bool> SelectByFrameTask(MyPoint leftTop, MyPoint rigthBot)
        {
            var task = new Task<bool>(() =>
            {
                _strategy.Action.Action = ActionType.ClearAndSelect;
                _strategy.Action.Left = leftTop.X;
                _strategy.Action.Top = leftTop.Y;
                _strategy.Action.Right = rigthBot.X;
                _strategy.Action.Bottom = rigthBot.Y;

                return true;
            });

            return task;
        }

        public Task<bool> AssignToGroupTask(Group group)
        {
            var task = new Task<bool>(() =>
            {
                _strategy.Action.Action = ActionType.Assign;
                _strategy.Action.Group = (int)group;
                _strategy.CurrentGroup = group;
                return true;
            });

            return task;
        }
    }
}
