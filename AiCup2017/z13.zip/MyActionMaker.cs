﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyActionMaker
    {

    }
}
