using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk {
    public sealed class MyStrategy : IStrategy {

        public Queue<Task<bool>> MainGameTasks { get; set; } = new Queue<Task<bool>>();
        public Queue<Task<bool>> NuclearGameTasks { get; set; } = new Queue<Task<bool>>();

        public List<MyUnitWithDelayedTask> Units { get; set; } = new List<MyUnitWithDelayedTask>();
        public List<MyUnitWithDelayedTask> UnitsForRemove { get; set; } = new List<MyUnitWithDelayedTask>();
        public List<MyUnitWithDelayedTask> UnitsForAdd { get; set; } = new List<MyUnitWithDelayedTask>();

        public Player Me { get; set; }
        public World World { get; set; }
        public Game Game { get; set; }
        public Move Action { get; set; }

        public Dictionary<long, Vehicle> VehicleById { get; set; } = new Dictionary<long, Vehicle>();
        public Dictionary<long, int> UpdateTickByVehicleId { get; set; } = new Dictionary<long, int>();

        public IEnumerable<Vehicle> MyVehicles{get { return VehicleById.Values.Where(v => v.PlayerId == Me.Id); }}
        public IEnumerable<Vehicle> EnemyVehicles { get { return VehicleById.Values.Where(v => v.PlayerId != Me.Id); }}

        public MyDelayTaksBuilder DelayTaksBuilder { get; set; }
        public MyEnemyStrategyRecognizer EnemyStrategyRecognizer { get; set; }
        public MyGameGrid GameGrid { get; set; }
        public MyActionMaker Act { get; set; }
        public MyIGroupMaker GroupMaker { get; set; }
        public MyIStrategyController StrategyController { get; set; }

        public MyIndicatorFacilites IndicatorFacillites { get; set; }
        public MyMissionManager MissionManager { get; set; }
        public MyGroupManager GroupManager { get; set; }

        public Group CurrentGroup { get; set; }
        public Group LastGroup { get; set; }
        public EnemyStrategyType EnemyType { get; set; } = EnemyStrategyType.Unknown;

        public bool EnemyNuclearReady { get; set; } = true;
        public bool NuclearAlarm { get; set; }
        public bool GroupingEnded { get; set; }
      
        public void Move(Player me, World world, Game game, Move move)
        {
            InitializeTick(me, world, game, move);

            if (me.RemainingActionCooldownTicks != 0) { return; }

            var nuclearAlarm =  CheckNuclearAlarm();
            if (nuclearAlarm) { return; }

            if (MainGameTasks.Any() && !NuclearAlarm)
            {
                MainGameTasks.Dequeue().RunSynchronously();
                return;
            }
        }

        private MyPoint _nuclearPoint = new MyPoint();
        private int _nuclearAlarmTick = 20001;
        private bool CheckNuclearAlarm()
        {
            if (GroupingEnded)
            {
                if (World.GetOpponentPlayer().RemainingNuclearStrikeCooldownTicks > 512 && EnemyNuclearReady)
                {
                    var x = World.GetOpponentPlayer().NextNuclearStrikeX;
                    var y = World.GetOpponentPlayer().NextNuclearStrikeY;
                    if (x <= 0 && y <= 0)
                    {
                        return false;
                    }
                    EnemyNuclearReady = false;

                    NuclearAlarm = true;

                    _nuclearAlarmTick = World.TickIndex;
                    _nuclearPoint = new MyPoint(x, y);
                    NuclearGameTasks.Enqueue(Act.SelectByFrameTask(new MyPoint(_nuclearPoint.X - 25, _nuclearPoint.Y - 25), new MyPoint(_nuclearPoint.X + 25, _nuclearPoint.Y + 25)));
                    NuclearGameTasks.Enqueue(Act.Scale(10, _nuclearPoint));
                }
                if (!EnemyNuclearReady)
                {
                    if (World.GetOpponentPlayer().RemainingNuclearStrikeCooldownTicks == 64)
                    {
                        EnemyNuclearReady = true;
                    }
                    if (World.TickIndex == _nuclearAlarmTick + 31)
                    {
                        NuclearGameTasks.Enqueue(Act.Scale(0.1, _nuclearPoint));
                        NuclearGameTasks.Enqueue(Act.SelectByGroup(CurrentGroup));
                    }
                    if (World.TickIndex == _nuclearAlarmTick + 61)
                    {
                        _nuclearAlarmTick = 20001;
                        NuclearAlarm = false;
                    }
                }
            }

            if (NuclearGameTasks.Any())
            {
                NuclearGameTasks.Dequeue().RunSynchronously();
                return true;
            }
            return false;
        }


        private void InitializeTick(Player me, World world, Game game, Move move)
        {           
            Me = me;
            World = world;
            Game = game;
            Action = move;

            foreach ( Vehicle vehicle in World.NewVehicles)
            {
                VehicleById[vehicle.Id] = vehicle;
                UpdateTickByVehicleId[vehicle.Id] = world.TickIndex;
            }

            foreach (VehicleUpdate vehicleUpdate in world.VehicleUpdates)
            {
                long vehicleId = vehicleUpdate.Id;

                if (vehicleUpdate.Durability == 0)
                {
                    VehicleById.Remove(vehicleId);
                    UpdateTickByVehicleId.Remove(vehicleId);
                }
                else
                {
                    VehicleById[vehicleId] =  new Vehicle(VehicleById[vehicleId], vehicleUpdate);
                    UpdateTickByVehicleId[vehicleId] = world.TickIndex;
                }
            }

            InitStrategy();

            if (World.TickIndex % 32 == 0)
            {
                IndicatorFacillites.Update(World.Facilities);
                GameGrid.Update(VehicleById.Values, World.Facilities);
                GroupManager.UpdateMissionForSquads();
            }

            UpDateDelayedTasks();


            if (GroupingEnded && Me.RemainingNuclearStrikeCooldownTicks <= 0)
            {
                if (World.TickIndex % 10 == 0)
                {
                    var myCenter = MyVehicles.CenterXY();
                    var enemyCenter = EnemyVehicles.CenterXY();
                    if (myCenter.GetSqrDistance(enemyCenter) < 10000)
                    {
                        var samoletId = MyVehicles
                            .Where(v => v.Durability > 95 &&
                                        (v.Type == VehicleType.Fighter || v.Type == VehicleType.Helicopter)).Select(v => v.Id).FirstOrDefault();
                        MainGameTasks.Enqueue(Act.Nuclear(new MyPoint(VehicleById[samoletId].X + 50, VehicleById[samoletId].Y + 50), samoletId));
                        MainGameTasks.Enqueue(Act.Scale(0.1));
                    }
                }
            }
        }

        private void UpDateDelayedTasks()
        {
            foreach (var unit in UnitsForRemove)
            {
                Units.Remove(unit);
            }
            UnitsForRemove.Clear();

            foreach (var unit in UnitsForAdd)
            {
                Units.Add(unit);
            }
            UnitsForAdd.Clear();

            foreach (var unit in Units)
            {
                unit.CheckDelayedTask();
            }
        }

        private void InitStrategy()
        {
            if (World.TickIndex == 0)
            {
                DelayTaksBuilder = new MyDelayTaksBuilder(this);
                EnemyStrategyRecognizer = new MyEnemyStrategyRecognizer(this);
                Act = new MyActionMaker(this);
                GameGrid = new MyGameGrid(this);
                MissionManager = new MyMissionManager(this);
                GroupManager = new MyGroupManager(this);



                IndicatorFacillites = new MyIndicatorFacilites(this);

                if (World.Facilities.Length == 0)
                {
                    GroupMaker = new MyFirstRoundGroupMaker(this);
                    StrategyController = new MyFirstRoundController(this);
                    GroupMaker.Ready += StrategyController.Process;
                    GroupMaker.Make();
                }
                else if (!Game.IsFogOfWarEnabled)
                {
                    GroupMaker = new MyFirstRoundGroupMaker(this);
                    StrategyController = new MyFirstRoundController(this);
                    GroupMaker.Ready += StrategyController.Process;
                    GroupMaker.Make();
                }
                else
                {
                    //������� ��� ������
                }
            }
        }

    }
}