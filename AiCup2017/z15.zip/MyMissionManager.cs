﻿using System.Collections.Generic;
using System.Linq;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyMissionManager
    {
        private MyStrategy _str;

        private List<MyMission> _missions = new List<MyMission>();

        public MyMissionManager(MyStrategy myStrategy)
        {
            _str = myStrategy;
        }

        public void AddMission(MyMission mission)
        {
            _missions.Add(mission);
        }

        public void SetupMissionToSquad(MySquad squad)
        {
            if (!_missions.Any()){ return; }

            var mission = _missions.FirstOrDefault();
            if (mission != null)
            {
                squad.OnDuty = true;
                _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(squad.Group));
                foreach (var task in mission.Mission)
                {
                    _str.MainGameTasks.Enqueue(task);
                }

                _missions.Remove(mission);
            }
        }
    }
}
