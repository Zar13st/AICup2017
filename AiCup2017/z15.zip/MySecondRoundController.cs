﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundController : MyIStrategyController
    {
        private MyStrategy _str;

        public MySecondRoundController(MyStrategy strategy)
        {
            _str = strategy;
        }

        public void Process()
        {
            
        }
    }
}
