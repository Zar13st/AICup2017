﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyIndicatorFacilites
    {
        private MyStrategy _str;

        private Dictionary<long, Facility> _prevFacilityById = new Dictionary<long, Facility>();

        public MyIndicatorFacilites(MyStrategy strategy)
        {
            _str = strategy;

            CreateStartingMissions();
        }

        public void Update(Facility[] facilities)
        {
            foreach (var facility in facilities)
            {
                var id = facility.Id;

                if (facility.VehicleType == null && facility.OwnerPlayerId == _str.Me.Id)
                {
                    _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Fighter, id));
                }
            }
        }

        private void CreateStartingMissions()
        {
            foreach (var facility in _str.World.Facilities)
            {
                _prevFacilityById[facility.Id] = facility;

                if (facility.OnMyGround())
                {
                    var queue = new Queue<Task<bool>>();
                    queue.Enqueue(_str.Act.MoveToPoint(facility.GetCenter()));

                    var mission = new MyMission()
                    {
                        Type = MissionType.GetEmptyFacility,
                        Mission = queue,
                    };

                    _str.MissionManager.AddMission(mission);
                }
            }
        }
    }
}
