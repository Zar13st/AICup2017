﻿using System.Collections.Generic;
using System.Linq;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGroupManager
    {
        private MyStrategy _str;

        private readonly List<MySquad> _squads  = new List<MySquad>();
        
        public MyGroupManager(MyStrategy myStrategy)
        {
            _str = myStrategy;
        }

        public void AddSquad(MySquad squad)
        {
            _squads.Add(squad);
        }

        public void UpdateMissionForSquads()
        {
            foreach (var squad in _squads.Where(s => !s.OnDuty))
            {
                _str.MissionManager.SetupMissionToSquad(squad);
            }
        }
    }
}
