﻿using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySquad
    {
        public Group Group { get; set; }

        public VehicleType VehicleType { get; set; }

        public bool OnDuty { get; set; }
    }
}
