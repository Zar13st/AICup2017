﻿using System;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGridPoint
    {
        public const int GameGridDelta = 64;

        public int X { get; set; }
        public int Y { get; set; }

        public MyGridPoint(double x, double y)
        {
            X = Convert.ToInt32(x) / GameGridDelta;
            Y = Convert.ToInt32(y) / GameGridDelta;
        }

        public MyGridPoint(int x, int y)
        {
            X = x;
            Y = y;
        }


    }
}
