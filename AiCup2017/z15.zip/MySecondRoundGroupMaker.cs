﻿using System;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundGroupMaker : MyIGroupMaker
    {
        private readonly MyStrategy _str;

        public MySecondRoundGroupMaker(MyStrategy strategy)
        {
            _str = strategy;
        }

        public void Make()
        {
            MakeGroups();

        }

        public event Action Ready;

        private void MakeGroups()
        {
            foreach (var typeInt in Enum.GetValues(typeof(VehicleType)))
            {
                VehicleType vehicleType = (VehicleType) typeInt;

                _str.MainGameTasks.Enqueue(_str.Act.SelectByTypeAndFrameTask(vehicleType, new MyPoint(0, 0), new MyPoint(_str.World.Width, _str.World.Height)));

                _str.MainGameTasks.Enqueue(_str.Act.AssignToGroupTask(vehicleType.ToGroup()));


                var squad = new MySquad()
                {
                    Group = vehicleType.ToGroup(),
                    VehicleType = vehicleType,
                };
                _str.GroupManager.AddSquad(squad);
            }

        }
    }
}
