﻿using System;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public static class MyGridPoinExtension
    {
        public static MyGridPoint GetGridPoint(this Vehicle vehicle)
        {
            return new MyGridPoint(vehicle.X, vehicle.Y);
        }

        public static MyPoint GetCenter(this MyGridPoint p)
        {
            return new MyPoint((p.X + 0.5) * MyGridPoint.GameGridDelta, (p.Y + 0.5) * MyGridPoint.GameGridDelta);
        }

        public static int GetCellX(this Vehicle vehicle)
        {
            return Convert.ToInt32(vehicle.X) / MyGridPoint.GameGridDelta;
        }

        public static int GetCellY(this Vehicle vehicle)
        {
            return Convert.ToInt32(vehicle.Y) / MyGridPoint.GameGridDelta;
        }

        public static bool OnMyGround(this Facility facility)
        {
            return facility.Top + facility.Left < 1024;
        }

        public static MyPoint GetCenter(this Facility facility)
        {
            var center = new MyPoint()
            {
                X = facility.Left + 32,
                Y = facility.Top + 32,
            };

            return center;
        }
    }
}
