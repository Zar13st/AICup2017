﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public interface MyINuclearEvader
    {
        bool CheckNuclearAlarm();
    }
}