﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyThirdRoundController : MyIStrategyController
    {
        public void Process()
        {
            
        }

        public void FindSingleEnemy(MySquad group)
        {
            
        }

        public MyPoint FindSingleEnemy(int group)
        {
            return new MyPoint();
        }
    }
}
