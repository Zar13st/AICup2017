﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum EnemyStrategyType
    {
        Unknown,
        Solo,
        Spread,
        Groups,
        SmallGroups,
        BigGroups
    }
}