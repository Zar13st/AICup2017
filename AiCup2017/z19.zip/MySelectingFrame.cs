﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySelectingFrame
    {
        public MySelectingFrame()
        {
        }

        public MySelectingFrame(MyPoint leftTop, MyPoint rigthBot)
        {
            LeftTop = leftTop;
            RigthBot = rigthBot;
        }

        public MyPoint LeftTop { get; set; }

        public MyPoint RigthBot { get; set; }
    }
}
