﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundController : MyIStrategyController
    {
        private MyStrategy _str;

        private Dictionary<double, MyGridCellInfo> _airTargets = new Dictionary<double, MyGridCellInfo>();

        public MySecondRoundController(MyStrategy strategy)
        {
            _str = strategy;
        }

        private int _process = 0;
        public void Process()
        {
            _process++;
            if (_process == 1)
            {

            }
            else if (_process == 2)
            {
                _str.GroupingEnded = true;
                AirScale();

                LandTopGo();
                LandLeftGo();
                LandTopRGo();
                LandLeftRGo();
                LandTanksGo();
            }
        }

        private void LandTanksGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.Tank);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Tank));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.3));

            _str.DelayTaksBuilder.Create(Group.Tank, TanksScale, 800);
        }

        private void LandLeftRGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandLeftR);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeftR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandLeftR, LeftRScale, 1200);
        }

        private void LandTopRGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandTopR);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTopR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandTopR, TopRScale, 1200);
        }

        private void LandLeftGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandLeft);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LeftScale, 800);
        }

        private void LandTopGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandTop);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandTop, TopScale, 800);
        }

        private bool even;
        private void AirGo()
        {
            if (!_str.EnemyVehicles.Any() || !_str.MyVehicles.Any()) { return; }

            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains((int)Group.Air));
            if (myRandomUnit == null) return;

            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            var targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Ifv && v.X < 800 && v.Y < 800);
            if (!targets.Any())
            {
                if (even)
                {
                    _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
                    _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(0, 512), 0.9d));

                    _str.DelayTaksBuilder.Create(Group.Air, AirRotate);
                    even = false;
                }
                else
                {
                    _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
                    _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(512, 0), 0.9d));

                    _str.DelayTaksBuilder.Create(Group.Air, AirRotate);
                    even = true;
                }

                return;
            }

            foreach (var vehicle in targets )
            {
                double currentDistance;
                try
                {
                    currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                }
                catch (Exception e)
                {
                    continue;
                }
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(nearestEnemyPoint.X, nearestEnemyPoint.Y), 0.9d));

            _str.DelayTaksBuilder.Create(Group.Air, AirRotate, 450);
        }

        private void AirScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.Air, AirGo);
        }

        private void AirRotate()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.FastCenterRotate(90));

            _str.DelayTaksBuilder.Create(Group.Air, AirScale);
        }

        private void TopScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            var myV = _str.MyVehicles.Where(v => v.Groups.Contains((int)Group.LandTop));
            if (myV == null || !myV.Any())
            {
                return;
            }
            var centerV = myV.CenterXY();
            if (_str.IndicatorFacillites.OnFacility(centerV))
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, LandTopGo, 200);
            }
            else
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, TopShift, 200);
            }
        }

        private void LeftScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));


            var myV = _str.MyVehicles.Where(v => v.Groups.Contains((int)Group.LandTop));
            if (myV == null || !myV.Any())
            {
                return;
            }
            var centerV = myV.CenterXY();
            if (_str.IndicatorFacillites.OnFacility(centerV))
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, LandLeftGo, 200);
            }
            else
            {
                _str.DelayTaksBuilder.Create(Group.LandLeft, LeftShift, 200);
            }
        }


        private void TopRScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTopR));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            var myV = _str.MyVehicles.Where(v => v.Groups.Contains((int)Group.LandTop));
            if (myV == null || !myV.Any())
            {
                return;
            }
            var centerV = myV.CenterXY();
            if (_str.IndicatorFacillites.OnFacility(centerV))
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, LandTopRGo, 200);
            }
            else
            {
                _str.DelayTaksBuilder.Create(Group.LandTopR, TopRShift, 200);
            }
        }

        private void LeftRScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeftR));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            var myV = _str.MyVehicles.Where(v => v.Groups.Contains((int)Group.LandTop));
            if (myV == null || !myV.Any())
            {
                return;
            }
            var centerV = myV.CenterXY();
            if (_str.IndicatorFacillites.OnFacility(centerV))
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, LandLeftRGo, 200);
            }
            else
            {
                _str.DelayTaksBuilder.Create(Group.LandLeftR, LeftRShift, 200);
            }
        }

        private void TanksScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Tank));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            var myV = _str.MyVehicles.Where(v => v.Groups.Contains((int)Group.LandTop));
            if (myV == null || !myV.Any())
            {
                return;
            }
            var centerV = myV.CenterXY();
            if (_str.IndicatorFacillites.OnFacility(centerV))
            {
                _str.DelayTaksBuilder.Create(Group.LandTop, LandTanksGo, 200);
            }
            else
            {
                _str.DelayTaksBuilder.Create(Group.Tank, TanksShift, 200);
            }


        }

        public void FindSingleEnemy(MySquad squad)
        {
            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains(squad.Id));
            if (myRandomUnit==null || !_str.EnemyVehicles.Any())return;
            
            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            IEnumerable<Vehicle> targets;
            switch (squad.VehicleType)
            {
                case VehicleType.Fighter:
                    targets = _str.EnemyVehicles.Where(v => v.Type == VehicleType.Fighter || v.Type == VehicleType.Helicopter);
                    break;
                case VehicleType.Helicopter:
                    targets = _str.EnemyVehicles.Where(v => v.Type == VehicleType.Tank || v.Type == VehicleType.Arrv);
                    break;
                case VehicleType.Tank:
                    targets = _str.EnemyVehicles.Where(v => v.Type == VehicleType.Tank || v.Type == VehicleType.Ifv || v.Type == VehicleType.Arrv);
                    break;
                default:
                    targets = _str.EnemyVehicles;
                    break;
            }

            if (targets == null || !targets.Any())
            {
                targets = _str.EnemyVehicles;
            }

            foreach (var vehicle in targets)
            {
                double currentDistance;
                try
                {
                    currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                }
                catch (Exception e)
                {
                    continue;
                }
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(squad.Id));
            _str.MainGameTasks.Enqueue(_str.Act.MoveToPoint(nearestEnemyPoint));
        }

        public MyPoint FindSingleEnemy(int group)
        {
            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains(group));
            if (myRandomUnit == null) new MyPoint(512, 512);
            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            IEnumerable<Vehicle> targets;
            switch (group)
            {
                case (int)Group.Tank:
                     targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Fighter && v.Type != VehicleType.Helicopter);
                    break;
                case (int)Group.LandLeft:
                    targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Tank && v.Type != VehicleType.Fighter);
                    break;
                case (int)Group.LandTop:
                    targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Tank && v.Type != VehicleType.Fighter);
                    break;
                    default:
                        targets = _str.EnemyVehicles;
                    break;
            }

            if (targets == null || !targets.Any()) new MyPoint(512, 512);


            foreach (var vehicle in targets)
            {
                double currentDistance;
                try
                {
                    currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                }
                catch (Exception e)
                {
                    continue;
                }

                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            return new MyPoint(nearestEnemyPoint.X, nearestEnemyPoint.Y);
        }


        private void TopShift()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.MoveByVector(new MyPoint(100, 0)));

            _str.DelayTaksBuilder.Create(Group.LandTop, LandTopGo, 200);
        }

        private void LeftShift()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.MoveByVector(new MyPoint(100, 0)));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LandLeftGo, 200);
        }


        private void TopRShift()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTopR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveByVector(new MyPoint(100, 0)));

            _str.DelayTaksBuilder.Create(Group.LandTopR, LandTopRGo, 200);
        }

        private void LeftRShift()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeftR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveByVector(new MyPoint(100, 0)));

            _str.DelayTaksBuilder.Create(Group.LandLeftR, LandLeftRGo, 200);
        }

        private void TanksShift()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Tank));
            _str.MainGameTasks.Enqueue(_str.Act.MoveByVector(new MyPoint(100, 0)));

            _str.DelayTaksBuilder.Create(Group.Tank, LandTanksGo, 200);
        }
    }
}
