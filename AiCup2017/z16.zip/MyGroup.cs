﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum Group
    {
        Remont = 1,
        Fighter,
        Helicopter,
        Zenitka,
        Tank,
        All,
        Air,
        Land,
        TankTop,
        TankBot,
        TankMid,
        Tank4,
        SamoletTop,
        SamoletBot,
        SamoletMid,
        Samolet4,
        ZenitkaTop,
        ZenitkaBot,
        ZenitkaMid,
        Zenitka4,
        RemontTop,
        RemontBot,
        RemontMid,
        CopterTop,
        CopterMid,
        Temp1,
        Temp2,
        Temp3,
    }
}
