﻿using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundController : MyIStrategyController
    {
        private MyStrategy _str;



        public MySecondRoundController(MyStrategy strategy)
        {
            _str = strategy;
        }

        private int _process = 0;
        public void Process()
        {
            _process++;
            if (_process == 1)
            {
                AirGo();
            }
            else if (_process == 2)
            {
                
            }
        }

        private void AirGo()
        {
            if (!_str.EnemyVehicles.Any() || !_str.MyVehicles.Any()) { return; }

            foreach (var cell in _str.GameGrid.Grid)
            {
                if (cell.EnemySamolets.Count + cell.EnemyCopters.Count > 0)
                {
                    _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
                    _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint((cell.X + 0.5) * 64, (cell.Y + 0.5) * 64), 0.9));

                    _str.DelayTaksBuilder.Create(Group.Air, AirScale);
                }
            }
        }

        private void AirScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.Air, AirRotate, 150);
        }

        private void AirRotate()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.FastCenterRotate(90));

            _str.DelayTaksBuilder.Create(Group.Air, AirGo, 300);
        }
    }
}
