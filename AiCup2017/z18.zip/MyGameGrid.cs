﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGameGrid
    {
        public const int GameGridDelta = 64;

        public MyGridCellInfo[,] Grid { get;}

        private readonly MyStrategy _strategy;
        private readonly int _cellCount;

        public MyGameGrid(MyStrategy strategy)
        {
            _strategy = strategy;

            _cellCount = Convert.ToInt32(strategy.World.Width)/ GameGridDelta;

            Grid = new MyGridCellInfo[_cellCount, _cellCount];

            for (var i = 0; i < _cellCount; i++)
            {
                for (var j = 0; j < _cellCount; j++)
                {
                    Grid[i, j] = new MyGridCellInfo(i, j);                   
                }
            }
        }

        public void Update(IEnumerable<Vehicle> vehicles, Facility[] facilities)
        {
            Clear();

            foreach (var squad in _strategy.GroupManager.Squads)
            {
                TakePosition(squad);
            }

            foreach (var facility in facilities)
            {
                SetupFacilitiesInfo(facility);
            }

            foreach (var v in vehicles)
            {
                UpdateVehicles(v);
            }
        }

        public void TakePosition(int x, int y, MySquad squad)
        {
            Grid[x, y].Squad = squad;
        }

        private void TakePosition(MySquad squad)
        {
            var center = _strategy.MyVehicles.Where(v => v.Groups.Contains(squad.Id)).CenterXY();

            squad.X = center.X.GetCellX();
            squad.Y = center.Y.GetCellY();

            //if (squad.HaveFacilityTarget)
            //{
            //    Grid[squad.TargetFacilityX, squad.TargetFacilityY].TagetSquad = squad.Id;
            //}

            //for (var i = -2; i < 3; i++)
            //{
            //    for (var j = -2; j < 3; j++)
            //    {
            //        var x = squad.X + i;
            //        var y = squad.Y + j;

            //        if (x < 0 || y < 0 || x >= 1024 / MyGameGrid.GameGridDelta || y >= 1024 / MyGameGrid.GameGridDelta){continue;}

            //        Grid[x, y].Squad = squad;
            //    }
            //}
            
        }


        private void SetupFacilitiesInfo(Facility facility)
        {
            Grid[facility.GetCellX(), facility.GetCellY()].Facility = facility;
        }


        private void UpdateVehicles(Vehicle vehicles)
        {
            
            var cellX = vehicles.GetCellX();
            var cellY = vehicles.GetCellY();

            var cellInfo = Grid[cellX, cellY];
            cellInfo.IsEnemyCell = true;

            switch (vehicles.Type)
            {
                case VehicleType.Arrv:
                        cellInfo.EnemyRemonts.Add(vehicles);
                    break;
                case VehicleType.Fighter:
                        cellInfo.EnemySamolets.Add(vehicles);
                    break;
                case VehicleType.Helicopter:
                        cellInfo.EnemyCopters.Add(vehicles);
                    break;
                case VehicleType.Ifv:
                        cellInfo.EnemyZeneitkas.Add(vehicles);
                    break;
                case VehicleType.Tank:
                        cellInfo.EnemyTanks.Add(vehicles);
                    break;
            }
        }

        private void Clear()
        {
            for (var i = 0; i < _cellCount; i++)
            {
                for (var j = 0; j < _cellCount; j++)
                {
                    Grid[i, j].Clear();
                }
            }
        }
    }
}
