﻿using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyIndicatorFacilites
    {
        private MyStrategy _str;

        private int _newSquadId = (int) Group.NewGroup;

        public MyIndicatorFacilites(MyStrategy strategy)
        {
            _str = strategy;
        }

        public void GetNearestFasility(MySquad squad)
        {
            squad.HaveFacilityTarget = false;
            double distToFacility = 10000d;
            foreach (var facility in _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id))
            {
                if (_str.GameGrid.Grid[facility.Left.GetCellX(), facility.Top.GetCellY()].TagetSquad != 0) continue;

                var distToCurrentFacility = squad.Distance(facility);
                if (distToCurrentFacility < distToFacility)
                {
                    distToFacility = distToCurrentFacility;

                    squad.TargetFacilityX = facility.Left.GetCellX();
                    squad.TargetFacilityY = facility.Top.GetCellY();
                    squad.HaveFacilityTarget = true;
                }
            }

            _str.GameGrid.Grid[squad.TargetFacilityX, squad.TargetFacilityY].TagetSquad = squad.Id;
        }

        public void Update(Facility[] facilities)
        {
            foreach (var facility in facilities)
            {
                var id = facility.Id;

                if (facility.Type == FacilityType.VehicleFactory && facility.OwnerPlayerId == _str.Me.Id)
                {
                    if (facility.VehicleType == null)
                    {
                        _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Fighter, id));
                    }

                    if (_str.World.TickIndex % 512 != 0) continue;

                    var newVehicleCount = _str.MyVehicles.Count(v =>
                        v.X >= facility.Left &&
                        v.X <= facility.Left + 64 &&
                        v.Y >= facility.Top &&
                        v.Y <= facility.Top + 64 &&
                        v.Groups.Length == 0);

                    if (newVehicleCount > 25)
                    {
                        var squad = new MySquad()
                        {
                            VehicleType = (VehicleType)facility.VehicleType,
                            Id = _newSquadId,
                            OnDuty = true,
                        };

                        var center = _str.MyVehicles.Where(v => v.Groups.Contains(squad.Id)).CenterXY();

                        squad.X = center.X.GetCellX();
                        squad.Y = center.Y.GetCellY();

                        _newSquadId++;

                        _str.GroupManager.Squads.Add(squad);
                        var lastGroupId = _str.CurrentGroup;
                        _str.MainGameTasks.Enqueue(_str.Act.SelectByTypeAndFrameTask((VehicleType)facility.VehicleType, new MyPoint(facility.Left, facility.Top), new MyPoint(facility.Left + 64, facility.Top + 64)));
                        _str.MainGameTasks.Enqueue(_str.Act.AssignToGroupTask(squad.Id));
                        _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1 , new MyPoint(facility.Left + 32, facility.Top -64)));
                        _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(lastGroupId));
                        var squadId = squad.Id;
                        _str.DelayTaksBuilder.Create(squadId, (() =>
                        {
                            var sid = squadId;
                            var squaOnDuty = _str.GroupManager.Squads.SingleOrDefault(s => s.Id == sid);
                                if (squaOnDuty != null)
                                {
                                    squaOnDuty.OnDuty = false;
                                }
                            }));
                    }
                }

            }

        }
    }
}
