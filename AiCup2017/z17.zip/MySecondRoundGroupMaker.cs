﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundGroupMaker : MyIGroupMaker
    {
        private int _dl = 80;

        private readonly MyStrategy _str;

        private Dictionary<Group, MyPoint> _positions = new Dictionary<Group, MyPoint>();

        public MySecondRoundGroupMaker(MyStrategy strategy)
        {
            _str = strategy;
        }

        public void Make()
        {
            MakeGroups();

            foreach (var typeInt in Enum.GetValues(typeof(VehicleType)))
            {
                var center = _str.MyVehicles.Where(v => (int)v.Type == (int)typeInt).CenterXY();

                int x = Convert.ToInt32(center.X);
                int y = Convert.ToInt32(center.Y);

                _positions[((VehicleType)typeInt).ToGroup()] = new MyPoint(x / _dl, y / _dl);
            }





            Ready?.Invoke();
        }

        public event Action Ready;

        private void MakeGroups()
        {
            foreach (var typeInt in Enum.GetValues(typeof(VehicleType)))
            {
                VehicleType vehicleType = (VehicleType) typeInt;

                int groupId = 0;

                MySquad squad;

                switch (vehicleType)
                {
                    case VehicleType.Fighter:
                        groupId = (int)Group.Fighter;
                        break;
                    case VehicleType.Arrv:
                        groupId = (int)Group.Remont;
                        break;
                    case VehicleType.Tank:
                        groupId = (int)Group.Tank;
                        break;
                    case VehicleType.Ifv:
                        groupId = (int)Group.Zenitka1;
                        break;
                    case VehicleType.Helicopter:
                        groupId = (int)Group.Copter1;
                        break;
                }

                _str.MainGameTasks.Enqueue(_str.Act.SelectByTypeAndFrameTask(vehicleType, new MyPoint(0, 0),new MyPoint(_str.World.Width, _str.World.Height)));

                _str.MainGameTasks.Enqueue(_str.Act.AssignToGroupTask((Group) groupId));

                _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

                squad = new MySquad()
                {
                    Id = groupId,
                    VehicleType = vehicleType,
                };

                if (squad.IsGroundSquad())
                {
                    _str.IndicatorFacillites.GetNearestFasility(squad);
                }

                //_str.GroupManager.AddSquad(squad);
            }
        }
    }
}
