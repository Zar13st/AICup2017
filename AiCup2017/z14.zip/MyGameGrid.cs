﻿using System;
using System.Collections.Generic;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGameGrid
    {
        public const int GameGridDelta = 64;

        public MyGridCellInfo[,] Grid { get;}

        private readonly MyStrategy _strategy;
        private readonly int _cellCount;

        public MyGameGrid(MyStrategy strategy)
        {
            _strategy = strategy;

            _cellCount = Convert.ToInt32(strategy.World.Width)/ GameGridDelta;

            Grid = new MyGridCellInfo[_cellCount, _cellCount];

            for (var i = 0; i < _cellCount; i++)
            {
                for (var j = 0; j < _cellCount; j++)
                {
                    Grid[i, j] = new MyGridCellInfo(i, j);                   
                }
            }
        }

        public void Update(IEnumerable<Vehicle> vehicles, Facility[] facilities)
        {
            Clear();

            UpdateFacilites(facilities);

            foreach (var v in vehicles)
            {
                UpdateVehicles(v);
            }
        }

        private void UpdateFacilites(Facility[] facilities)
        {
            foreach (var f in facilities)
            {
                var x = Convert.ToInt32(f.Left) / GameGridDelta;
                var y = Convert.ToInt32(f.Top) / GameGridDelta;

                Grid[x, y].Facility = f;
            }
        }


        private void UpdateVehicles(Vehicle vehicles)
        {
            var cellX = vehicles.GetCellX();
            var cellY = vehicles.GetCellY();

            var cellInfo = Grid[cellX, cellY];

            switch (vehicles.Type)
            {
                case VehicleType.Arrv:
                    if (vehicles.PlayerId == _strategy.Me.Id)
                    {
                        cellInfo.MyRemonts.Add(vehicles);
                    }
                    else
                    {
                        cellInfo.EnemyRemonts.Add(vehicles);
                    }
                    break;
                case VehicleType.Fighter:
                    if (vehicles.PlayerId == _strategy.Me.Id)
                    {
                        cellInfo.MySamolets.Add(vehicles);
                    }
                    else
                    {
                        cellInfo.EnemySamolets.Add(vehicles);
                    }
                    break;
                case VehicleType.Helicopter:
                    if (vehicles.PlayerId == _strategy.Me.Id)
                    {
                        cellInfo.MyCopters.Add(vehicles);
                    }
                    else
                    {
                        cellInfo.EnemyCopters.Add(vehicles);
                    }
                    break;
                case VehicleType.Ifv:
                    if (vehicles.PlayerId == _strategy.Me.Id)
                    {
                        cellInfo.MyZeneitkas.Add(vehicles);
                    }
                    else
                    {
                        cellInfo.EnemyZeneitkas.Add(vehicles);
                    }
                    break;
                case VehicleType.Tank:
                    if (vehicles.PlayerId == _strategy.Me.Id)
                    {
                        cellInfo.MyTanks.Add(vehicles);
                    }
                    else
                    {
                        cellInfo.EnemyTanks.Add(vehicles);
                    }
                    break;
            }
        }

        private void Clear()
        {
            for (var i = 0; i < _cellCount; i++)
            {
                for (var j = 0; j < _cellCount; j++)
                {
                    Grid[i, j].Clear();
                }
            }
        }
    }
}
