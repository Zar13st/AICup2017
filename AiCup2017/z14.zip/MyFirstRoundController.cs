﻿using System.Linq;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyFirstRoundController : MyIStrategyController
    {
        private readonly MyStrategy _str;
        private readonly MyPoint _nearestEnemyPoint = new MyPoint();

        public MyFirstRoundController(MyStrategy str)
        {
            _str = str;
        }

        public void Process()
        {
            _str.EnemyType = _str.EnemyStrategyRecognizer.Recognize();

            switch (_str.EnemyType)
            {
                case EnemyStrategyType.Solo:
                {
                    _str.GroupingEnded = true;
                    GoToBigGroup();

                    break;
                }
                case EnemyStrategyType.Spread:
                {
                    FindSingleEnemy();
                    break;
                }
                default:
                    break;
            }
        }

        private void GoToBigGroup()
        {
            var enemyCenter = _str.EnemyVehicles.CenterXY();

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(Group.All));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(enemyCenter.X, enemyCenter.Y)));

            _str.DelayTaksBuilder.Create(Group.All, Process);
        }

        private void FindSingleEnemy()
        {
            var myRandomUnit = _str.MyVehicles.First();

            double distance = 10000;
            foreach (var vehicle in _str.EnemyVehicles)
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    _nearestEnemyPoint.X = vehicle.X;
                    _nearestEnemyPoint.Y = vehicle.Y;
                }
            }
            KillSingleEnemy();
        }


        private void KillSingleEnemy()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(Group.All));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(_nearestEnemyPoint, 0.3d));

            _str.DelayTaksBuilder.Create(Group.All, FindSingleEnemy);
        }
    }
}
