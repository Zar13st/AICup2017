﻿using System.Collections.Generic;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGridCellInfo
    {
        public MyGridCellInfo(int x, int y)
        {
            X = x;
            Y = y;
        }

        public List<Vehicle> EnemyTanks { get; } = new List<Vehicle>();
        public List<Vehicle> EnemySamolets { get;  } = new List<Vehicle>();
        public List<Vehicle> EnemyCopters { get;  } = new List<Vehicle>();
        public List<Vehicle> EnemyZeneitkas { get;  } = new List<Vehicle>();
        public List<Vehicle> EnemyRemonts { get;  } = new List<Vehicle>();

        public List<Vehicle> MyTanks { get; } = new List<Vehicle>();
        public List<Vehicle> MySamolets { get;  } = new List<Vehicle>();
        public List<Vehicle> MyCopters { get; } = new List<Vehicle>();
        public List<Vehicle> MyZeneitkas { get;  } = new List<Vehicle>();
        public List<Vehicle> MyRemonts { get; } = new List<Vehicle>();

        public Facility Facility { get; set; }

        public int X { get;  }
        public int Y { get; }      

        public void Clear()
        {
            EnemyTanks.Clear();
            EnemySamolets.Clear();
            EnemyCopters.Clear();
            EnemyZeneitkas.Clear();
            EnemyRemonts.Clear();
            MyTanks.Clear();
            MySamolets.Clear();
            MyCopters.Clear();
            MyZeneitkas.Clear();
            MyRemonts.Clear();
        }
    }
}
