﻿using System;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyEnemyStrategyRecognizer
    {
        private MyStrategy _strategy;

        public MyEnemyStrategyRecognizer(MyStrategy strategy)
        {
            _strategy = strategy;
        }

        public EnemyStrategyType Recognize()
        {
            Vehicle randomTank;
            try
            {
                randomTank = _strategy.EnemyVehicles.First(v => v.Type == VehicleType.Tank);

            }
            catch (Exception e)
            {
                randomTank = _strategy.EnemyVehicles.First();
            }
            var groupSize = _strategy.EnemyVehicles.Count(v => v.GetDistanceTo(randomTank.X, randomTank.Y) < 150);


            if (groupSize >= 150)
            {
                return EnemyStrategyType.Solo;
            }
            else
            {
                return EnemyStrategyType.Spread;
            }

        }
    }
}
