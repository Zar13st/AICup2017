﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum Group
    {
        Remont = 1,
        Fighter,
        Helicopter,
        Zenitka,
        Tank,
        All,
        Air,
        Land,
        Tank1,
        Tank2,
        Tank3,
        Tank4,
        Air1,
        Air2,
        Air3,
        Air4,
        Zenitka1,
        Zenitka2,
        Zenitka3,
        Zenitka4,
        Temp1,
        Temp2,
        Temp3,
    }
}
