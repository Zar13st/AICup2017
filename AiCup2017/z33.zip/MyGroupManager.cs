﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyGroupManager
    {
        private MyStrategy _str;

        private MyGridCellInfo[,] _grid;

        public  List<MySquad> Squads { get;}  = new List<MySquad>();
        
        public MyGroupManager(MyStrategy myStrategy)
        {
            _str = myStrategy;
            _grid = myStrategy.GameGrid.Grid;
        }

        public void AddBigSquad(MySquad squad)
        {
            Squads.Add(squad);
        }

        public void AddSquad(MySquad squad)
        {
            _str.DelayTaksBuilder.Create((Group) squad.Id, () =>
            {
                Squads.Add(squad);
                if (Squads.Count >= 5)
                {
                    _str.GroupingEnded = true;
                }
            });      
        }

        //public void UpdateMissionForSquads()
        //{
        //    if (!_str.GroupingEnded){return;}

        //    foreach (var squad in Squads.Where(s => !s.OnDuty))
        //    {
        //        switch (squad.VehicleType)
        //        {
        //            case VehicleType.Fighter:
        //                ScelectTargetForSamolet(squad);
        //                break;
        //            case VehicleType.Helicopter:
        //                if (_str.World.TickIndex % 32 != 0)
        //                {
        //                    ScelectTargetForCopter(squad);
        //                }
        //                break;
        //            case VehicleType.Ifv:
        //                if (_str.World.TickIndex % 128 != 0)
        //                {
        //                    ScelectTargetForZenitka(squad);
        //                }
        //                break;
        //            case VehicleType.Tank:
        //                if (_str.World.TickIndex % 128 != 0)
        //                {
        //                    ScelectTargetForTank(squad);
        //                }
        //                break;
        //            case VehicleType.Arrv:
        //                if (_str.World.TickIndex % 128 != 0)
        //                {
        //                    ScelectTargetForRemont(squad);
        //                }
        //                break;
        //        }

        //    }
        //}

        //private void ScelectTargetForSamolet(MySquad squad)
        //{
        //    var x = squad.X ;
        //    var y = squad.Y ;
        //    double value = -1000000;

        //    if (_grid[squad.X, squad.Y].EnemySamolets.Count > 1)
        //    {
        //        squad.OnDuty = true;


        //    }


        //    for (int i = squad.X - 1; i <= squad.X + 1; i++)
        //    {
        //        for (int j = squad.Y - 1; j <= squad.Y + 1; j++)
        //        {
        //            if (i < 1 || j < 1 || i >= 63 || j >= 63 ) { continue; }
        //            if (_grid[i,j].Squad.Id != squad.Id && !squad.IsGroundSquad()) { continue;}
        //            if (_grid[i, j].EnemySamolets.Count == 0 && _grid[i, j].EnemyCopters.Count == 0 && _grid[i, j].EnemyZeneitkas.Count > 1) { continue; }
        //            if (_grid[i, j].EnemyZeneitkas.Count > 5) { continue; }
        //            if (_grid[i, j].Facility != null && 
        //                _grid[i, j].Facility.Type == FacilityType.VehicleFactory && 
        //                _grid[i, j].Facility.OwnerPlayerId == _str.Me.Id && 
        //               (_grid[i, j].Facility.VehicleType == VehicleType.Fighter || 
        //                _grid[i, j].Facility.VehicleType == VehicleType.Helicopter)) { continue; }

        //            double currentCellValue = 0;

        //            foreach (var cellInfo in _grid)
        //            {
        //                double distToCell;
        //                //if (cellInfo.EnemySamolets.Count > 0 || cellInfo.EnemyCopters.Count > 0 || cellInfo.EnemyZeneitkas.Count > 0)
        //                //{
        //                    distToCell = cellInfo.Distance(_grid[i, j]);
        //                //}
        //                //else
        //                //{
        //                //    continue;
        //                //}

        //                if (cellInfo.EnemySamolets.Count > 0)
        //                {
        //                    currentCellValue += 10 * cellInfo.EnemySamolets.Count * Math.Pow(2, -distToCell / 1028d);
        //                }

        //                if (cellInfo.EnemyCopters.Count > 0)
        //                {
        //                    currentCellValue += cellInfo.EnemyCopters.Count *  Math.Pow(2, -distToCell / 1028d);
        //                }

        //            }

        //            if (currentCellValue >= value)
        //            {
        //                x = i;
        //                y = j;
        //                value = currentCellValue;
        //            }
        //        }
        //    }

        //    _grid[x, y].Squad = squad;

        //    if (x == squad.X && y == squad.Y && x == squad.NextX && y == squad.NextY)
        //    {
        //        return;
        //    }

        //    squad.NextX = x;
        //    squad.NextY = y;

        //    squad.NextTask.Clear();
        //    squad.NextTask.Enqueue(_str.Act.SelectByGroup(squad.Id));
        //    squad.NextTask.Enqueue(_str.Act.MoveToPoint(new MyPoint((x + 0.5) * MyGameGrid.GameGridDelta, (y + 0.5) * MyGameGrid.GameGridDelta)));       
        //}

        //private void ScelectTargetForCopter(MySquad squad)
        //{
        //    var x = squad.X;
        //    var y = squad.Y;
        //    double value = -100000;

        //    for (int i = squad.X - 1; i <= squad.X + 1; i++)
        //    {
        //        for (int j = squad.Y - 1; j <= squad.Y + 1; j++)
        //        {
        //            if (i < 1 || j < 1 || i >= 63  || j >= 63) { continue; }
        //            if (_grid[i, j].Squad.Id != squad.Id && !squad.IsGroundSquad()) { continue; }
        //            if (_grid[i, j].EnemyTanks.Count == 0 && _grid[i, j].EnemyRemonts.Count == 0 && _grid[i, j].EnemySamolets.Count > 1) { continue; }
        //            if (_grid[i, j].Facility != null &&
        //                _grid[i, j].Facility.Type == FacilityType.VehicleFactory &&
        //                _grid[i, j].Facility.OwnerPlayerId == _str.Me.Id &&
        //               (_grid[i, j].Facility.VehicleType == VehicleType.Fighter ||
        //                _grid[i, j].Facility.VehicleType == VehicleType.Helicopter)) { continue; }

        //            double currentCellValue = 0;

        //            foreach (var cellInfo in _grid)
        //            {
        //                double distToCell;
        //                //if (cellInfo.EnemySamolets.Count > 0 || cellInfo.EnemyCopters.Count > 0 || cellInfo.EnemyZeneitkas.Count > 0 || cellInfo.EnemyRemonts.Count > 0 || cellInfo.EnemyTanks.Count > 0)
        //                //{
        //                    distToCell = cellInfo.Distance(_grid[i, j]);
        //                //}
        //                //else
        //                //{
        //                //    continue;
        //                //}


        //                if (distToCell < 400 && cellInfo.EnemySamolets.Count > 2)
        //                {
        //                    currentCellValue +=  -10 * cellInfo.EnemySamolets.Count * Math.Pow(2, -distToCell / 1024d);
        //                    continue;
        //                }

        //                if (cellInfo.EnemyTanks.Count > 0)
        //                {
        //                    currentCellValue += 2 * cellInfo.EnemyTanks.Count * Math.Pow(2, -distToCell / 1024d);
        //                }

        //                if (cellInfo.EnemyRemonts.Count > 0)
        //                {
        //                    currentCellValue += 1 * cellInfo.EnemyRemonts.Count * Math.Pow(2, -distToCell / 1024d);
        //                }

        //                if (cellInfo.EnemyZeneitkas.Count > 0)
        //                {
        //                    currentCellValue += 1/10 * cellInfo.EnemyZeneitkas.Count * Math.Pow(2, -distToCell / 1024d);
        //                }

        //                if (cellInfo.EnemyCopters.Count > 0)
        //                {
        //                    currentCellValue += 1/5 * cellInfo.EnemyCopters.Count * Math.Pow(2, -distToCell / 1024d);
        //                }

        //            }

        //            if (currentCellValue > value)
        //            {
        //                x = i;
        //                y = j;
        //                value = currentCellValue;
        //            }
        //        }
        //    }

        //    _grid[x, y].Squad = squad;

        //    if (x == squad.X && y == squad.Y && x == squad.NextX && y == squad.NextY) { return; }

        //    squad.NextX = x;
        //    squad.NextY = y;

        //    squad.NextTask.Clear();
        //    squad.NextTask.Enqueue(_str.Act.SelectByGroup(squad.Id));
        //    squad.NextTask.Enqueue(_str.Act.MoveToPoint(new MyPoint((x + 0.5) * MyGameGrid.GameGridDelta, (y + 0.5) * MyGameGrid.GameGridDelta)));
        //}

        //private void ScelectTargetForTank(MySquad squad)
        //{
        //    var x = squad.X;
        //    var y = squad.Y;
        //    double value = -100000;

        //    for (int i = squad.X - 1; i <= squad.X + 1; i++)
        //    {
        //        for (int j = squad.Y - 1; j <= squad.Y + 1; j++)
        //        {
        //            if (i < 1 || j < 1 || i >= 63  || j >= 63) { continue; }
        //            if (_grid[i, j].Squad.Id != squad.Id && squad.IsGroundSquad()) { continue; }
        //            if (_grid[i, j].Facility != null &&
        //                _grid[i, j].Facility.Type == FacilityType.VehicleFactory &&
        //                _grid[i, j].Facility.OwnerPlayerId == _str.Me.Id) { continue; }

        //            double currentCellValue = 0;

        //            foreach (var cellInfo in _grid)
        //            {
        //                if (cellInfo.Facility != null && cellInfo.TagetSquad == squad.Id)
        //                {
        //                    if (cellInfo.Facility.OwnerPlayerId != _str.Me.Id)
        //                    {
        //                        currentCellValue += 10 * Math.Pow(32, -cellInfo.Distance(_grid[i, j]) / 512d);
        //                    }
        //                    else
        //                    {
        //                        _str.IndicatorFacillites.GetNearestFasility(squad);
        //                        return;
        //                    }
        //                }
        //            }

        //            if (currentCellValue >= value)
        //            {
        //                x = i;
        //                y = j;
        //                value = currentCellValue;
        //            }
        //        }
        //    }

        //    _grid[x, y].Squad = squad;

        //    if (x == squad.X && y == squad.Y && x == squad.NextX && y == squad.NextY) { return; }
        //    squad.NextX = x;
        //    squad.NextY = y;

        //    var dXnext = 0;
        //    var dYnext = 0;
        //    if (_grid[x, y].Facility == null)
        //    {
        //        dXnext = x - squad.X;
        //        dYnext = y - squad.Y;
        //    }

        //    squad.NextTask.Clear();
        //    squad.NextTask.Enqueue(_str.Act.SelectByGroup(squad.Id));
        //    squad.NextTask.Enqueue(_str.Act.MoveToPoint(new MyPoint((x + 0.5) * MyGameGrid.GameGridDelta, (y + 0.5) * MyGameGrid.GameGridDelta)));
        //}

        //private void ScelectTargetForZenitka(MySquad squad)
        //{
        //    var x = squad.X;
        //    var y = squad.Y;
        //    double value = -100000;

        //    for (int i = squad.X - 1; i <= squad.X + 1; i++)
        //    {
        //        for (int j = squad.Y - 1; j <= squad.Y + 1; j++)
        //        {
        //            if (i < 1 || j < 1 || i >= 63  || j >= 63) { continue; }
        //            if (_grid[i, j].Squad.Id != squad.Id && squad.IsGroundSquad()) { continue; }
        //            if (_grid[i, j].EnemyTanks.Count > 0) { continue; }
        //            if (_grid[i, j].Facility != null &&
        //                _grid[i, j].Facility.Type == FacilityType.VehicleFactory &&
        //                _grid[i, j].Facility.OwnerPlayerId == _str.Me.Id) { continue; }

        //            double currentCellValue = 0;

        //            foreach (var cellInfo in _grid)
        //            {
        //                if (cellInfo.Facility != null  && cellInfo.TagetSquad == squad.Id)
        //                {
        //                    if (cellInfo.Facility.OwnerPlayerId != _str.Me.Id)
        //                    {
        //                        currentCellValue += 10 * Math.Pow(32, -cellInfo.Distance(_grid[i, j]) / 512d);
        //                    }
        //                    else
        //                    {
        //                        _str.IndicatorFacillites.GetNearestFasility(squad);
        //                        return;                           
        //                    }
        //                }
        //            }

        //            if (currentCellValue >= value)
        //            {
        //                x = i;
        //                y = j;
        //                value = currentCellValue;
        //            }
        //        }
        //    }

        //    _grid[x, y].Squad = squad;

        //    if (x == squad.X && y == squad.Y && x == squad.NextX && y == squad.NextY) { return; }
        //    squad.NextX = x;
        //    squad.NextY = y;

        //    var dXnext = 0;
        //    var dYnext = 0;
        //    if (_grid[x, y].Facility == null)
        //    {
        //        dXnext = x - squad.X;
        //        dYnext = y - squad.Y;
        //    }

        //    squad.NextTask.Clear();
        //    squad.NextTask.Enqueue(_str.Act.SelectByGroup(squad.Id));
        //    squad.NextTask.Enqueue(_str.Act.MoveToPoint(new MyPoint((x  + 0.5) * MyGameGrid.GameGridDelta, (y  + 0.5) * MyGameGrid.GameGridDelta)));
        //}

        //private void ScelectTargetForRemont(MySquad squad)
        //{
        //    var x = squad.X;
        //    var y = squad.Y;
        //    double value = -100000;

        //    for (int i = squad.X - 1; i <= squad.X + 1; i++)
        //    {
        //        for (int j = squad.Y - 1; j <= squad.Y + 1; j++)
        //        {
        //            if (i < 1 || j < 1 || i >= 63  || j >= 63) { continue; }
        //            if (_grid[i, j].Squad.Id != squad.Id && squad.IsGroundSquad()) { continue; }
        //            if (_grid[i, j].EnemyCopters.Count > 0 || _grid[i, j].EnemyZeneitkas.Count > 0 || _grid[i, j].EnemyTanks.Count > 0) { continue; }
        //            if (_grid[i, j].Facility != null &&
        //                _grid[i, j].Facility.Type == FacilityType.VehicleFactory &&
        //                _grid[i, j].Facility.OwnerPlayerId == _str.Me.Id ) { continue; }

        //            double currentCellValue = 0;

        //            foreach (var cellInfo in _grid)
        //            {
        //                if (cellInfo.Facility != null && cellInfo.TagetSquad == squad.Id)
        //                {
        //                    if (cellInfo.Facility.OwnerPlayerId != _str.Me.Id)
        //                    {
        //                        currentCellValue += 10 * Math.Pow(32, -cellInfo.Distance(_grid[i, j]) / 512d);
        //                    }
        //                    else
        //                    {
        //                        _str.IndicatorFacillites.GetNearestFasility(squad);
        //                        return;
        //                    }
        //                }
        //            }

        //            if (currentCellValue >= value)
        //            {
        //                x = i;
        //                y = j;
        //                value = currentCellValue;
        //            }
        //        }
        //    }

        //    _grid[x, y].Squad = squad;

        //    if (x == squad.X && y == squad.Y && x == squad.NextX && y == squad.NextY) { return; }
        //    squad.NextX = x;
        //    squad.NextY = y;

        //    var dXnext = 0;
        //    var dYnext = 0;
        //    if (_grid[x, y].Facility == null)
        //    {
        //        dXnext = x - squad.X;
        //        dYnext = y - squad.Y;
        //    }

        //    squad.NextTask.Clear();
        //    squad.NextTask.Enqueue(_str.Act.SelectByGroup(squad.Id));
        //    squad.NextTask.Enqueue(_str.Act.MoveToPoint(new MyPoint((x + 0.5) * MyGameGrid.GameGridDelta, (y + 0.5) * MyGameGrid.GameGridDelta)));
        //}
    }
}
