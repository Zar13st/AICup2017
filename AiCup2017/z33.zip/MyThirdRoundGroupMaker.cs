﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyThirdRoundGroupMaker : MyIGroupMaker
    {
        private int _dl = 80;

        private readonly MyStrategy _str;

        private Dictionary<Group, MyPoint> _positions = new Dictionary<Group, MyPoint>();

        public event Action Ready;

        public MyThirdRoundGroupMaker(MyStrategy strategy)
        {
            _str = strategy;
        }

        public void Make()
        {
            foreach (var typeInt in Enum.GetValues(typeof(VehicleType)))
            {
                var center = _str.MyVehicles.Where(v => (int)v.Type == (int)typeInt).CenterXY();

                int x = Convert.ToInt32(center.X);
                int y = Convert.ToInt32(center.Y);

                _positions[((VehicleType)typeInt).ToGroup()] = new MyPoint(x / _dl, y / _dl);
            }
            _str.MainGameTasks.Enqueue(_str.Act.SelectByFrameTask(new MyPoint(0, 0), new MyPoint(_str.World.Width, _str.World.Height)));

            _str.MainGameTasks.Enqueue(_str.Act.AssignToGroupTask(Group.All));

            for (var i=2; i>=0; i--)
            {
                
            }
        }
    }
}
