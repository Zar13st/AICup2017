﻿using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundController : MyIStrategyController
    {
        private MyStrategy _str;

        private Dictionary<double, MyGridCellInfo> _airTargets = new Dictionary<double, MyGridCellInfo>();

        public MySecondRoundController(MyStrategy strategy)
        {
            _str = strategy;
        }

        private int _process = 0;
        public void Process()
        {
            _process++;
            if (_process == 1)
            {
                AirGo();
            }
            else if (_process == 2)
            {
                LandTopGo();
                LandLeftGo();
            }
        }

        private void LandLeftGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility((int) Group.LandLeft, false);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X + 10, target.Y + 30), 0.3));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LeftScale);
        }

        private void LandTopGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility((int)Group.LandTop, true);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X + 10, target.Y + 30), 0.3));

            _str.DelayTaksBuilder.Create(Group.LandTop, TopScale);
        }

        private void AirGo()
        {
            if (!_str.EnemyVehicles.Any() || !_str.MyVehicles.Any()) { return; }

            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains((int)Group.Air));
            if (myRandomUnit == null) return;

            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            foreach (var vehicle in _str.EnemyVehicles.Where(v =>  v.Type != VehicleType.Ifv))
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(nearestEnemyPoint.X, nearestEnemyPoint.Y), 0.9d));

            _str.DelayTaksBuilder.Create(Group.Air, AirScale);
        }

        private void AirScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.Air, AirRotate);
        }

        private void AirRotate()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.FastCenterRotate(180));

            _str.DelayTaksBuilder.Create(Group.Air, AirGo);
        }

        private void TopScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandTop, LandTopGo, 200);
        }

        private void LeftScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LandLeftGo, 200);
        }

        public void FindSingleEnemy(MySquad group)
        {
            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains(group.Id));
            if (myRandomUnit==null)return;
            
            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            foreach (var vehicle in _str.EnemyVehicles.Where(v => v.Type != VehicleType.Fighter && v.Type != VehicleType.Helicopter ))
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(group.Id));
            _str.MainGameTasks.Enqueue(_str.Act.MoveToPoint(nearestEnemyPoint));
        }
    }
}
