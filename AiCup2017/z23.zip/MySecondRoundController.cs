﻿using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySecondRoundController : MyIStrategyController
    {
        private MyStrategy _str;

        private Dictionary<double, MyGridCellInfo> _airTargets = new Dictionary<double, MyGridCellInfo>();

        public MySecondRoundController(MyStrategy strategy)
        {
            _str = strategy;
        }

        private int _process = 0;
        public void Process()
        {
            _process++;
            if (_process == 1)
            {
                AirScale();
            }
            else if (_process == 2)
            {
                LandTopGo();
                LandLeftGo();
                LandTopRGo();
                LandLeftRGo();
                LandTanksGo();
            }
        }

        private void LandTanksGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.Tank);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Tank));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.3));

            _str.DelayTaksBuilder.Create(Group.Tank, TanksScale);
        }

        private void LandLeftRGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandLeftR);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeftR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandLeftR, LeftRScale);
        }

        private void LandTopRGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandTopR);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTopR));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandTopR, TopRScale);
        }

        private void LandLeftGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandLeft);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LeftScale);
        }

        private void LandTopGo()
        {
            var target = _str.IndicatorFacillites.GetNearestFasility(Group.LandTop);

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(target.X, target.Y + 10), 0.4));

            _str.DelayTaksBuilder.Create(Group.LandTop, TopScale);
        }

        private void AirGo()
        {
            if (!_str.EnemyVehicles.Any() || !_str.MyVehicles.Any()) { return; }

            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains((int)Group.Air));
            if (myRandomUnit == null) return;

            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            foreach (var vehicle in _str.EnemyVehicles.Where(v =>  v.Type != VehicleType.Ifv && v.X < 750 && v.Y < 750))
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.MoveSlowToPoint(new MyPoint(nearestEnemyPoint.X, nearestEnemyPoint.Y), 0.9d));

            _str.DelayTaksBuilder.Create(Group.Air, AirRotate, 450);
        }

        private void AirScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.Air, AirGo);
        }

        private void AirRotate()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Air));
            _str.MainGameTasks.Enqueue(_str.Act.FastCenterRotate(90));

            _str.DelayTaksBuilder.Create(Group.Air, AirScale);
        }

        private void TopScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTop));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandTop, LandTopGo, 200);
        }

        private void LeftScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeft));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandLeft, LandLeftGo, 200);
        }


        private void TopRScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandTopR));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandTopR, LandTopRGo, 200);
        }

        private void LeftRScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.LandLeftR));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.LandLeftR, LandLeftRGo, 200);
        }

        private void TanksScale()
        {
            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup((int)Group.Tank));
            _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1));

            _str.DelayTaksBuilder.Create(Group.Tank, LandTanksGo, 200);
        }

        public void FindSingleEnemy(MySquad squad)
        {
            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains(squad.Id));
            if (myRandomUnit==null || !_str.EnemyVehicles.Any())return;
            
            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            IEnumerable<Vehicle> targets;
            switch (squad.VehicleType)
            {
                case VehicleType.Fighter:
                    targets = _str.EnemyVehicles.Where(v => v.Type == VehicleType.Fighter && v.Type == VehicleType.Helicopter);
                    break;
                case VehicleType.Helicopter:
                    targets = _str.EnemyVehicles.Where(v => v.Type == VehicleType.Tank && v.Type == VehicleType.Arrv);
                    break;
                case VehicleType.Tank:
                    targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Fighter && v.Type != VehicleType.Helicopter);
                    break;
                default:
                    targets = _str.EnemyVehicles;
                    break;
            }

            if (targets == null || !targets.Any()) targets = _str.EnemyVehicles;

            foreach (var vehicle in targets)
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(squad.Id));
            _str.MainGameTasks.Enqueue(_str.Act.MoveToPoint(nearestEnemyPoint));
        }

        public MyPoint FindSingleEnemy(int group)
        {
            var myRandomUnit = _str.MyVehicles.FirstOrDefault(v => v.Groups.Contains(group));
            if (myRandomUnit == null) new MyPoint(512, 512);
            var nearestEnemyPoint = new MyPoint();
            double distance = 10000;
            IEnumerable<Vehicle> targets;
            switch (group)
            {
                case (int)Group.Tank:
                     targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Fighter && v.Type != VehicleType.Helicopter);
                    break;
                case (int)Group.LandLeft:
                    targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Tank && v.Type != VehicleType.Fighter);
                    break;
                case (int)Group.LandTop:
                    targets = _str.EnemyVehicles.Where(v => v.Type != VehicleType.Tank && v.Type != VehicleType.Fighter);
                    break;
                    default:
                        targets = _str.EnemyVehicles;
                    break;
            }

            if (targets == null || !targets.Any()) new MyPoint(512, 512);


            foreach (var vehicle in targets)
            {
                var currentDistance = vehicle.GetDistanceTo(myRandomUnit);
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    nearestEnemyPoint.X = vehicle.X;
                    nearestEnemyPoint.Y = vehicle.Y;
                }
            }

            return new MyPoint(nearestEnemyPoint.X, nearestEnemyPoint.Y);
        }
    }
}
