﻿using System.Collections.Generic;
using System.Linq;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MyIndicatorFacilites
    {
        private MyStrategy _str;

        private int _facilityCount;

        private int _newSquadId = (int) Group.NewGroup;

        public MyIndicatorFacilites(MyStrategy strategy)
        {
            _str = strategy;
        }

        public MyPoint GetNearestFasility(Group group)
        {
            var squad = _str.GroupManager.Squads.Single(s => s.Id == (int)group);

            if (squad == null) return new MyPoint(500, 300);

            double distToFacility = 10000d;
            IEnumerable<Facility> facilities;
            switch (group)
            {
                case Group.LandTopR:
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id && v.Left - v.Top >= 512);
                    break;

                case Group.LandTop:
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id && v.Left - v.Top < 512 && v.Left - v.Top >= 128);
                    break;

                case Group.Tank:
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id && v.Left - v.Top < 128 && v.Left - v.Top > - 128);
                    break;

                case Group.LandLeft:
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id && v.Left - v.Top <= -128 && v.Left - v.Top > -512);
                    break;

                case Group.LandLeftR:
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id && v.Left - v.Top <= -512);
                    break;
                    default:
                        facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id);
                    break;
            }

            if (facilities == null || !facilities.Any())
            {
                if (group == Group.LandLeftR || group == Group.LandTopR)
                {
                    facilities = _str.World.Facilities.Where(v => v.OwnerPlayerId != _str.Me.Id);
                }
                else
                {
                    return _str.StrategyController.FindSingleEnemy((int)group);

                }
            }

            MyPoint point = new MyPoint();
            foreach (var facility in facilities)
            {
                var distToCurrentFacility = squad.Distance(facility);
                if (distToCurrentFacility < distToFacility)
                {
                    distToFacility = distToCurrentFacility;

                    point.X = facility.Left + 32;
                    point.Y = facility.Top + 32;
                }
            }

            return point;
        }

        public void Update(Facility[] facilities)
        {
            foreach (var facility in facilities)
            {
                var id = facility.Id;

                if (facility.Type == FacilityType.VehicleFactory && facility.OwnerPlayerId == _str.Me.Id)
                {
                    if (facility.VehicleType == null)
                    {
                        switch (_facilityCount)
                        {
                            case 0:
                                _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Fighter, id));
                                break;
                            case 1:
                                _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Helicopter, id));
                                break;
                            case 2:
                                _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Tank, id));
                                break;
                            default:
                                if (_facilityCount % 2 == 1)
                                {
                                    _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Tank, id));
                                }
                                else
                                {
                                    _str.MainGameTasks.Enqueue(_str.Act.SetupVehicleProduction(VehicleType.Helicopter, id));
                                }
                                break;
                        }
                        _facilityCount++;
                    }

                    if (_str.World.TickIndex % 512 != 0) continue;

                    var newVehicleCount = _str.MyVehicles.Count(v =>
                        v.X >= facility.Left &&
                        v.X <= facility.Left + 64 &&
                        v.Y >= facility.Top &&
                        v.Y <= facility.Top + 64 &&
                        v.Groups.Length == 0);

                    if (newVehicleCount > 25)
                    {
                        var squad = new MySquad()
                        {
                            VehicleType = (VehicleType)facility.VehicleType,
                            Id = _newSquadId,
                        };

                        _str.GroupManager.Squads.Add(squad);

                        _newSquadId++;


                        var lastGroupId = _str.CurrentGroup;
                        _str.MainGameTasks.Enqueue(_str.Act.SelectByTypeAndFrameTask((VehicleType)facility.VehicleType, new MyPoint(facility.Left, facility.Top), new MyPoint(facility.Left + 64, facility.Top + 64)));
                        _str.MainGameTasks.Enqueue(_str.Act.AssignToGroupTask(squad.Id));

                        var distToCenter = facility.Distance(512, 512);
                        var normVector = new MyPoint((512 - facility.Left + 32) / distToCenter, (512 - facility.Top + 8) / distToCenter);

                        _str.MainGameTasks.Enqueue(_str.Act.Scale(0.1 , new MyPoint(facility.Left + normVector.X * 100, facility.Top + normVector.Y * 100)));
                        _str.MainGameTasks.Enqueue(_str.Act.SelectByGroup(lastGroupId));
                    }
                }

            }

        }
    }
}
