﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class MySquad
    {
        public int Id { get; set; }

        public VehicleType VehicleType { get; set; }

        public bool OnDuty { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        public int NextX { get; set; }

        public int NextY { get; set; }

        public Queue<Task<bool>>  NextTask { get; set; } = new Queue<Task<bool>>();

        public bool HaveFacilityTarget { get; set; }

        public int TargetFacilityX { get; set; }

        public int TargetFacilityY { get; set; }
    }
}
