﻿using System;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public interface MyIGroupMaker
    {
        void Make();

        event Action Ready;
    }   
}
