﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum Group
    {
        Remont = 1,
        Fighter,
        Helicopter,
        Zenitka,
        Tank,
        All,
        Temp1,
        Temp2,
        Air,
        Land,
        LandTop,
        LandLeft,
        LandTopR,
        LandLeftR,
        Remont1,
        Tank1,
        Zenitka1,
        Copter1,
        NewGroup,
    }
}
